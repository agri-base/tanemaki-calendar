'use client';

import TanemakiCalendar from './TanemakiCalendar';

export default function Home() {
  return <TanemakiCalendar />;
}
